package mongoteamrepo

import (
	"context"
	"openfinance/domain"

	"go.mongodb.org/mongo-driver/bson"

	"go.mongodb.org/mongo-driver/mongo"
)

const (
	COLLECTION = "team"
)

type repository struct {
	dbName string
	client *mongo.Client
}

func NewRepository(client *mongo.Client, dbName string) *repository {
	return &repository{
		client: client,
		dbName: dbName,
	}
}

func (repo *repository) Add(ctx context.Context, team domain.Team) (err error) {
	_, err = repo.client.Database(repo.dbName).Collection(COLLECTION).InsertOne(ctx, team)
	if err != nil {
		return
	}
	return
}

func (repo *repository) Get(ctx context.Context, id string) (team domain.Team, err error) {
	err = repo.client.Database(repo.dbName).Collection(COLLECTION).FindOne(ctx, bson.M{"_id": id}).Decode(&team)
	if err != nil {
		return
	}
	return
}
