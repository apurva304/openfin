package teamrepository

import (
	"context"
	"openfinance/domain"
)

type Repository interface {
	Add(ctx context.Context, team domain.Team) (err error)
	Get(ctx context.Context, id string) (team domain.Team, err error)
}
