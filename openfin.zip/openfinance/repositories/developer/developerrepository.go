package developerrepository

import (
	"context"
	"openfinance/domain"
)

type Repository interface {
	Add(ctx context.Context, dev domain.Developer) (err error)
	AddBulk(ctx context.Context, devs []domain.Developer) (err error)
	Get(ctx context.Context, id string) (dev domain.Developer, err error)
	List(ctx context.Context, teamId string) (devs []domain.Developer, err error)
}
