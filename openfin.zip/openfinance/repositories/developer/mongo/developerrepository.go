package mongodeveloperrepository

import (
	"context"
	"openfinance/domain"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
)

const (
	COLLECTION = "developer"
)

type repository struct {
	dbName string
	client *mongo.Client
}

func NewRepository(client *mongo.Client, dbName string) *repository {
	return &repository{
		client: client,
		dbName: dbName,
	}
}

func (repo *repository) Add(ctx context.Context, dev domain.Developer) (err error) {
	_, err = repo.client.Database(repo.dbName).Collection(COLLECTION).InsertOne(ctx, dev)
	if err != nil {
		return
	}
	return
}
func (repo *repository) AddBulk(ctx context.Context, devs []domain.Developer) (err error) {
	for _, d := range devs {
		_, err = repo.client.Database(repo.dbName).Collection(COLLECTION).InsertOne(ctx, d)
		if err != nil {
			return
		}
	}

	return
}
func (repo *repository) Get(ctx context.Context, id string) (dev domain.Developer, err error) {
	err = repo.client.Database(repo.dbName).Collection(COLLECTION).FindOne(ctx, bson.M{"_id": id}).Decode(&dev)
	if err != nil {
		return
	}
	return
}
func (repo *repository) List(ctx context.Context, teamId string) (devs []domain.Developer, err error) {
	cur, err := repo.client.Database(repo.dbName).Collection(COLLECTION).Find(ctx, bson.M{"team_id": teamId})
	if err != nil {
		return
	}

	err = cur.All(ctx, &devs)
	if err != nil {
		return
	}
	return
}
