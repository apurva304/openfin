package notificationclient

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
)

type service struct {
	client  *http.Client
	baseUrl string
}

func NewService(client *http.Client, baseUrl string) *service {
	return &service{
		client:  client,
		baseUrl: baseUrl,
	}
}

func (svc *service) Notify(ctx context.Context, phone string, msg string) (err error) {
	type payload struct {
		PhoneNumber string `json:"phone_number"`
		Message     string `json:"message"`
	}

	data := payload{
		PhoneNumber: phone,
		Message:     msg,
	}

	jsonData, err := json.Marshal(data)
	if err != nil {
		return
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, svc.baseUrl, bytes.NewReader(jsonData))
	if err != nil {
		return
	}

	res, err := svc.client.Do(req)
	if err != nil {
		return
	}

	if res.StatusCode != http.StatusOK {
		err = errors.New("Error sending the notification")
		return
	}
	return
}
