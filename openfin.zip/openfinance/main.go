package main

import (
	"context"
	"net/http"
	notifierclient "openfinance/notifier/client"
	mongodeveloperrepository "openfinance/repositories/developer/mongo"
	mongoteamrepository "openfinance/repositories/team/mongo"
	service "openfinance/service"

	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const uri = "mongodb://localhost:27017"

func main() {

	client, err := mongo.Connect(context.Background(), options.Client().ApplyURI(uri))
	if err != nil {
		panic(err)
	}

	notifier := notifierclient.NewService(http.DefaultClient, "https://run.mocky.io/v3/fd99c100-f88a-4d70-aaf7-393dbbd5d99f")
	dbName := "barraiser"
	devRepo := mongodeveloperrepository.NewRepository(client, dbName)
	teamRepo := mongoteamrepository.NewRepository(client, dbName)

	svc := service.NewService(notifier, teamRepo, devRepo)
	r := service.MakeHandler(svc)

	http.ListenAndServe(":3000", r)
}
