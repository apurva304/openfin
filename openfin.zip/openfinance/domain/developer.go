package domain

type Developer struct {
	Id          string `json:"id" bson:"_id"`
	TeamId      string `json:"teamId" bson:"teamId"`
	Name        string `json:"name" bson:"name"`
	PhoneNumber string `json:"phoneNumber" bson:"phoneNumber"`
}
