package service

import (
	"encoding/json"
	"net/http"
	"openfinance/domain"

	"github.com/gorilla/mux"
)

func MakeHandler(svc Service) http.Handler {
	r := mux.NewRouter()

	r.HandleFunc("/team", getCreateTeamHandler(svc)).Methods(http.MethodPost)
	r.HandleFunc("/aleart/{teamId}", getAleartHandler(svc)).Methods(http.MethodGet)
	return r
}

func getCreateTeamHandler(svc Service) http.HandlerFunc {
	return func(rw http.ResponseWriter, r *http.Request) {
		type payloadData struct {
			Team       domain.Team        `json:"team"`
			Developers []domain.Developer `json:"developers"`
		}
		var body payloadData

		err := json.NewDecoder(r.Body).Decode(&body)
		if err != nil {
			http.Error(rw, "Bad Request", http.StatusBadRequest)
			return
		}

		err = svc.CreateTeam(r.Context(), body.Team, body.Developers)
		if err != nil {
			http.Error(rw, "Error creating team"+err.Error(), http.StatusInternalServerError)
		}

		return
	}
}

func getAleartHandler(svc Service) http.HandlerFunc {
	return func(rw http.ResponseWriter, r *http.Request) {
		params := mux.Vars(r)
		teamId := params["teamId"]

		if len(teamId) < 1 {
			http.Error(rw, "Bad Request", http.StatusBadRequest)
			return
		}

		err := svc.Aleart(r.Context(), teamId)
		if err != nil {
			http.Error(rw, "Error creating team", http.StatusInternalServerError)
			return
		}
	}

}
