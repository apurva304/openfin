package service

import (
	"context"
	"math/rand"
	"openfinance/domain"
	"openfinance/notifier"
	developerrepository "openfinance/repositories/developer"
	teamrepository "openfinance/repositories/team"

	"go.mongodb.org/mongo-driver/bson/primitive"
)

type Service interface {
	CreateTeam(ctx context.Context, team domain.Team, devs []domain.Developer) (err error)
	Aleart(ctx context.Context, teamId string) (err error)
}

type service struct {
	notifierSvc notifier.Notifier
	teamRepo    teamrepository.Repository
	devRepo     developerrepository.Repository
}

func NewService(notifierSvc notifier.Notifier, teamRepo teamrepository.Repository, devRepo developerrepository.Repository) *service {
	return &service{
		notifierSvc: notifierSvc,
		teamRepo:    teamRepo,
		devRepo:     devRepo,
	}
}

func (svc *service) CreateTeam(ctx context.Context, team domain.Team, devs []domain.Developer) (err error) {
	team.Id = primitive.NewObjectID().Hex()

	for _, d := range devs {
		d.Id = primitive.NewObjectID().Hex()
		d.TeamId = team.Id
	}

	err = svc.teamRepo.Add(ctx, team)
	if err != nil {
		return
	}

	err = svc.devRepo.AddBulk(ctx, devs)
	if err != nil {
		return
	}
	return
}
func (svc *service) Aleart(ctx context.Context, teamId string) (err error) {
	devs, err := svc.devRepo.List(ctx, teamId)
	if err != nil {
		return
	}

	randomDev := devs[rand.Intn(len(devs))]

	err = svc.notifierSvc.Notify(ctx, randomDev.PhoneNumber, "Too many 5xx!")
	if err != nil {
		return
	}
	return
}
